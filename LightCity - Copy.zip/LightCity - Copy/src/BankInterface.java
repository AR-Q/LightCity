
public interface BankInterface {
}
