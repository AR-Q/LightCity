

public interface GameInterface {
     void continueGame(User user);
     void startGame(User user);

     void joinServer(String ip ,int port);

     void generateNewCity();


}
