

public interface CityInterface {
    void joinCharacter(User character);
    void getCityDetail();
}
