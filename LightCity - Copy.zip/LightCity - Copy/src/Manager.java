

public class Manager extends Employee{

    public Manager(String username, Industry industry, float baseSalary, BankAccount bankAccount) {
        super(username, industry, baseSalary, bankAccount);
    }
}
