
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class City implements CityInterface {
    private final ArrayList<Character> characters;
    private final Bank bankSystem;
    private final Municipality municipality;

    private final StockMarket stockMarket;

    private Character root;

    public City() {
        characters = new ArrayList<>();
        municipality = new Municipality();
        // Get Bank Property from municipality
        bankSystem = new Bank(new Property(new float[] { 12, 32 }, new float[] { 42, 32 }, root), root);
        stockMarket = new StockMarket();
        stockMarket.startMarketSimulation();
    }

    @Override
    public void joinCharacter(User userinfo) {
        BankAccount newAccount = bankSystem.newAccount(userinfo.getUsername(), userinfo.getPassword());
        Character character = new Character(userinfo, newAccount, new Life(), null, null, null);
        characters.add(character);
        beginGame(character);
    }

    @Override
    public void getCityDetail() {
        String players = Arrays.toString(characters.toArray());
    }

    /**
     * Begin Game function generate a new thread for each character ,<b > DO NOT
     * CHANGE THIS FUNCTION STRUCTURE</b> ,
     *
     */
    private void beginGame(Character character) {
        Thread thread = new Thread(() -> {
            try {
                Scanner scanner = new Scanner(System.in);
                while (true) {
                    System.out.println("Show Menu");
                    System.out.println("Goto [1]");
                    System.out.println("Process Location [2]");
                    System.out.println("Dashboard [3]");
                    System.out.println("Life [4]");
                    System.out.println("Exit [5]");
                    switch (scanner.next()) {
                        case "1" -> {
                            System.out.println("Goto");
                            System.out.println("Enter Industry title : ");
                            String title = scanner.nextLine();
                            Property property = municipality.FindIndustry(title);
                            character.gotToLocation(property);
                        }
                        case "2" -> {
                            System.out.println("Process location");
                            character.positionProcessing();
                        }
                        case "3" -> {
                            System.out.println("Dashboard");
                            System.out.println("ّMy Job [1]");
                            System.out.println("Properties [2]");
                            System.out.println("Economy [3]");
                            switch (scanner.next()) {
                                case "1" -> {
                                    System.out.println("Find Job [1]");

                                    switch (scanner.next()) {
                                        case "1" -> character.getJob();
                                    }
                                }

                                case "2" -> {
                                    System.out.println("Show Properties [1]");
                                    System.out.println("Sell [2]");
                                    System.out.println("Management [3]");
                                    System.out.println("Found Industry [4]");

                                    switch (scanner.next()) {
                                        case "1" -> character.getProperties();
                                        case "2" -> System.out.println("Sell");
                                        case "3" -> System.out.println("Manage");
                                        case "4" -> System.out.println("FounfIndustry");

                                    }
                                }

                                case "3" -> {
                                    System.out.println("Show incomes [1]");
                                    System.out.println("Show job detail [2]");
                                    System.out.println("How can grow up ? [3]");

                                    switch (scanner.next()) {
                                        case "1" -> System.out.println("incomes");
                                        case "2" -> System.out.println("detail");
                                        case "3" -> System.out.println("grow");

                                    }
                                }

                            }

                        }

                        case "4" -> {
                            System.out.println("Life Detail [1]");
                            System.out.println("Sleep function [2]");
                            System.out.println("Eat function [3]");
                            System.out.println("");

                            switch (scanner.next()) {
                                case "1" -> System.out.println("Detail");
                                case "2" -> System.out.println("Sleep function");
                                case "3" -> System.out.println("Eat function");

                            }
                        }

                        case "5" -> {
                            System.out.println("Are you sure ?");
                            System.out.println("Yes [1]");
                            System.out.println("No [2]");

                            switch (scanner.next()) {
                                case "1" -> throw new Exception("");

                            }
                        }

                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        thread.start();
    }
}
