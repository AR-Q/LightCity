
import java.util.Scanner;

public class Menu {
    private static Game game = new Game();
    private static Scanner scanner = new Scanner(System.in);

    public static void showMenu() {
        mainMenu();
        System.out.println("Continue [1]");
        System.out.println("New Game [2]");
        System.out.println("Join Server [3]");
        System.out.println("Exit [4]");

        System.out.print("Enter your Command : ");

        String next = scanner.next();
        if (next.equals("1")) {
            game.continueGame(loginMenu());
        } else if (next.equals("2")) {
            game.startGame(loginMenu());
        } else if (next.equals("3")) {
            joinServer();
        } else if (next.equals("4"))
            System.exit(0);
    }

    public static void mainMenu() {
        // show menu : sout ()
    }

    public static User loginMenu() {
        // get user info : username, password
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Username : ");
        String username = scanner.nextLine();

        System.out.print("Enter Password : ");
        String password = scanner.nextLine();

        User user = Database.FindUser(username, password);
        
        return user;
    }

    private static void joinServer() {
        System.out.print("Enter Server Ip Address :");
        String ip = scanner.next();
        System.out.print("Enter Server Port :");
        int port = scanner.nextInt();
        game.joinServer(ip, port);
    }

    public static void main(String[] args) {
        showMenu();
    }
}
