

public interface MunicipalityInterface {

//    Buy and sell property
    Property buyProperty();
    void sellProperty(Property property);
    void showProperties();
}
