

public interface CharacterInterface {
    void positionProcessing();

}
